# data sets
The data sets for the impact test

## accel_1
Data set marked as accelerometer #1.

## accel_4
Data set marked as accelerometer #4.



















