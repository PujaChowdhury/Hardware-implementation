# data sets
Jon sent me these data sets, but they are all the same data.






















