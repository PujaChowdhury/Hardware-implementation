# data sets
The data sets were passed around form person to person for about 4 years, in 2021, Austin Downey at the UofSC tried his best to rebuild the original data set. These are the source files from people. 






















